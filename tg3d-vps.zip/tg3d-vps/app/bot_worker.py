"""Telegram polling worker for receiving GLB files in the bot chat."""
import asyncio
import os
import re
import secrets
import shutil
import sqlite3
import struct
import time
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Document, InlineKeyboardButton, InlineKeyboardMarkup, Message, WebAppInfo

ROOT = Path(os.environ.get('MODELS_DIR', '/var/lib/tg3d/models'))
ROOT.mkdir(parents=True, exist_ok=True)
DB = ROOT.parent / 'models.sqlite3'
TOKEN = os.environ['BOT_TOKEN']
PUBLIC_URL = os.environ.get('PUBLIC_URL', 'https://n1kma3d.online').rstrip('/')
MAX_UPLOAD = int(os.environ.get('MAX_UPLOAD_BYTES', 41943040))
TELEGRAM_DOWNLOAD_LIMIT = 20 * 1024 * 1024
TTL = int(os.environ.get('MODEL_TTL_HOURS', 36)) * 3600
ALLOWED_EXTENSIONS = {'.glb', '.stl', '.obj', '.fbx', '.stp', '.step'}


def connect():
    db = sqlite3.connect(DB, timeout=15)
    db.row_factory = sqlite3.Row
    return db


def clean_name(name: str) -> str:
    name = (name or 'model.glb').replace('\\', '/').split('/')[-1]
    name = ''.join(c for c in name if ord(c) >= 32)[:180]
    return name


def validate_glb(path: Path, expected_size: int) -> None:
    if expected_size < 20 or expected_size > MAX_UPLOAD:
        raise ValueError('Размер GLB должен быть не больше 40 МиБ.')
    if path.stat().st_size != expected_size:
        raise ValueError('Файл из Telegram скачался не полностью.')
    with path.open('rb') as source:
        header = source.read(20)
    if len(header) != 20:
        raise ValueError('Файл слишком короткий для GLB 2.0.')
    magic, version, length, json_length, json_type = struct.unpack('<5I', header)
    if magic != 0x46546C67 or version != 2 or length != expected_size or json_type != 0x4E4F534A or json_length > expected_size - 20:
        raise ValueError('Нужен корректный файл GLB 2.0.')


def save_model(path: Path, owner: int, name: str, size: int) -> str:
    mid = 'v_' + secrets.token_urlsafe(24)
    suffix = Path(name).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise ValueError('Поддерживаются GLB, STL, OBJ, FBX, STP и STEP.')
    final = ROOT / (mid + suffix)
    now = time.time()
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        used = db.execute('SELECT COALESCE(SUM(size),0) FROM models').fetchone()[0]
        if used + size > 10 * 1024**3 or shutil.disk_usage(ROOT).free < size + 1024**3:
            raise ValueError('На сервере закончилось свободное место.')
        db.execute('INSERT INTO models VALUES (?,?,?,?,?,0)', (mid, name, owner, size, now))
    path.replace(final)
    with connect() as db:
        db.execute('UPDATE models SET ready=1 WHERE id=?', (mid,))
    return mid


def open_keyboard(mid: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(
        text='Открыть 3D-модель',
        web_app=WebAppInfo(url=f'{PUBLIC_URL}/?model={mid}'),
    )]])


async def start(message: Message):
    await message.answer(
        'Отправь мне модель как документ — я загружу её в 3D-просмотрщик.\n'
        'Поддерживаются GLB, STL, OBJ, FBX, STP и STEP.',
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(
            text='Открыть 3D-Viewer', web_app=WebAppInfo(url=f'{PUBLIC_URL}/'),
        )]]),
    )


async def document(message: Message, bot: Bot):
    doc: Document = message.document
    name = doc.file_name or 'model.glb'
    suffix = Path(name).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        await message.answer('Поддерживаются GLB, STL, OBJ, FBX, STP и STEP.')
        return
    size = int(doc.file_size or 0)
    if size > TELEGRAM_DOWNLOAD_LIMIT:
        await message.answer('Telegram Bot API позволяет скачать из чата файл не больше 20 МиБ. Больший файл загрузи через Mini App.')
        return
    if size < 20 or size > MAX_UPLOAD:
        await message.answer('Файл должен быть не меньше 20 байт и не больше 20 МиБ.')
        return
    if not message.from_user:
        return
    part = ROOT / ('.chat_' + secrets.token_hex(16) + '.part')
    try:
        await message.answer('Получил файл, проверяю GLB…')
        tg_file = await bot.get_file(doc.file_id)
        if not tg_file.file_path:
            raise ValueError('Telegram не вернул путь к файлу.')
        await bot.download_file(tg_file.file_path, destination=part)
        if suffix == '.glb':
            validate_glb(part, size)
        mid = await asyncio.to_thread(save_model, part, message.from_user.id, clean_name(name), size)
        await message.answer('Модель загружена. Она будет доступна 36 часов.', reply_markup=open_keyboard(mid))
    except ValueError as exc:
        part.unlink(missing_ok=True)
        await message.answer(str(exc))
    except Exception:
        part.unlink(missing_ok=True)
        await message.answer('Не удалось обработать файл. Попробуй ещё раз или загрузи модель через Mini App.')


async def main():
    bot = Bot(TOKEN)
    dp = Dispatcher()
    dp.message.register(start, CommandStart())
    dp.message.register(document, F.document)
    await bot.delete_webhook(drop_pending_updates=False)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


if __name__ == '__main__':
    asyncio.run(main())
