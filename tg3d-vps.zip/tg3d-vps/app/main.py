"""GLB storage for Telegram Mini Apps. No bot token is sent to the browser."""
import asyncio
import hashlib
import hmac
import json
import logging
import os
from pathlib import Path
import re
import secrets
import shutil
import sqlite3
import struct
import time
from contextlib import asynccontextmanager
from urllib.parse import parse_qsl, unquote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse

ROOT = Path(os.environ.get('MODELS_DIR', '/var/lib/tg3d/models'))
ROOT.mkdir(parents=True, exist_ok=True)
DB = ROOT.parent / 'models.sqlite3'
TOKEN = os.environ.get('BOT_TOKEN', '')
LIMIT = int(os.environ.get('MAX_UPLOAD_BYTES', 41943040))
TTL = int(os.environ.get('MODEL_TTL_HOURS', 36)) * 3600
GATE = asyncio.Semaphore(2)
LOG = logging.getLogger('uvicorn.error')


def connect():
    db = sqlite3.connect(DB, timeout=15)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('CREATE TABLE IF NOT EXISTS models (id TEXT PRIMARY KEY, name TEXT NOT NULL, owner INTEGER NOT NULL, size INTEGER NOT NULL, created REAL NOT NULL, ready INTEGER NOT NULL DEFAULT 0)')
        db.execute('CREATE INDEX IF NOT EXISTS models_created ON models(created)')


def authenticate(raw):
    if not TOKEN or not raw or len(raw) > 16384:
        raise HTTPException(401, 'Открой приложение заново через Telegram.')
    try:
        pairs = parse_qsl(raw, keep_blank_values=True, strict_parsing=True)
        data = dict(pairs)
        if len(data) != len(pairs):
            raise ValueError()
        received = data.pop('hash')
        check = '\n'.join(f'{k}={v}' for k, v in sorted(data.items()))
        secret = hmac.new(b'WebAppData', TOKEN.encode(), hashlib.sha256).digest()
        expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, received):
            raise ValueError()
        age = time.time() - int(data['auth_date'])
        if age < -60 or age > 86400:
            raise ValueError()
        uid = json.loads(data['user'])['id']
        if not isinstance(uid, int) or isinstance(uid, bool) or uid <= 0:
            raise ValueError()
        return uid
    except (ValueError, KeyError, TypeError):
        raise HTTPException(401, 'Сессия недействительна. Закрой и заново открой приложение в Telegram.')


def cleanup():
    now = time.time()
    with connect() as db:
        rows = db.execute('SELECT id FROM models WHERE created < ? OR (ready=0 AND created < ?)', (now - TTL, now - 3600)).fetchall()
        for row in rows:
            for suffix in ('.glb', '.part'):
                (ROOT / (row['id'] + suffix)).unlink(missing_ok=True)
            db.execute('DELETE FROM models WHERE id=?', (row['id'],))
    # Remove leftovers after a crash before a database reservation.
    for part in ROOT.glob('*.part'):
        if part.stat().st_mtime < now - 3600:
            part.unlink(missing_ok=True)


async def housekeeping():
    while True:
        try:
            await asyncio.to_thread(cleanup)
        except Exception:
            LOG.exception('Cleanup failed')
        await asyncio.sleep(300)


@asynccontextmanager
async def lifespan(app):
    if not TOKEN or ':' not in TOKEN:
        raise RuntimeError('Set BOT_TOKEN in /etc/tg3d.env')
    init_db()
    task = asyncio.create_task(housekeeping())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)


@app.get('/api/health')
def health():
    return {'ok': True, 'maxUploadBytes': LIMIT, 'ttlHours': TTL // 3600}


def get_model(mid):
    if not re.fullmatch(r'v_[A-Za-z0-9_-]{32}', mid):
        raise HTTPException(404, 'Модель не найдена.')
    with connect() as db:
        row = db.execute('SELECT * FROM models WHERE id=? AND ready=1', (mid,)).fetchone()
    if not row or time.time() >= row['created'] + TTL or not (ROOT / (mid + '.glb')).is_file():
        raise HTTPException(404, 'Модель удалена или срок хранения 36 часов истёк.')
    return row


@app.get('/api/models/{mid}')
def metadata(mid: str):
    row = get_model(mid)
    return {'id': mid, 'name': row['name'], 'size': row['size'], 'expiresAt': row['created'] + TTL}


@app.get('/api/models/{mid}/file')
def model_file(mid: str):
    row = get_model(mid)
    remaining = max(0, int(row['created'] + TTL - time.time()))
    return FileResponse(ROOT / (mid + '.glb'), media_type='model/gltf-binary', headers={
        'Cache-Control': f'public, max-age={min(3600, remaining)}', 'X-Content-Type-Options': 'nosniff'})


@app.post('/api/models', status_code=201)
async def upload(request: Request):
    owner = authenticate(request.headers.get('x-telegram-init-data', ''))
    try:
        size = int(request.headers.get('content-length', '0'))
    except ValueError:
        raise HTTPException(400, 'Некорректный размер файла.')
    if size < 20 or size > LIMIT:
        raise HTTPException(413, 'Размер GLB должен быть не больше 40 МиБ.')
    name = unquote(request.headers.get('x-file-name', 'model.glb'))
    name = name.replace('\\', '/').split('/')[-1]
    name = ''.join(c for c in name if ord(c) >= 32)[:180]
    if not name.lower().endswith('.glb'):
        raise HTTPException(400, 'Поддерживается только GLB.')
    if GATE.locked():
        raise HTTPException(429, 'Сервер занят загрузками. Повтори через минуту.')
    async with GATE:
        mid = 'v_' + secrets.token_urlsafe(24)
        part, final = ROOT / (mid + '.part'), ROOT / (mid + '.glb')
        now = time.time()
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            used = db.execute('SELECT COALESCE(SUM(size),0) FROM models').fetchone()[0]
            daily = db.execute('SELECT COUNT(*), COALESCE(SUM(size),0) FROM models WHERE owner=? AND created>?', (owner, now - 86400)).fetchone()
            if daily[0] >= 100 or daily[1] + size > 500 * 1024**2:
                raise HTTPException(429, 'Достигнут лимит загрузок: 100 файлов или 500 МиБ за сутки.')
            if used + size > 10 * 1024**3 or shutil.disk_usage(ROOT).free < size + 1024**3:
                raise HTTPException(507, 'Хранилище заполнено. Повтори позже.')
            db.execute('INSERT INTO models VALUES (?,?,?,?,?,0)', (mid, name, owner, size, now))
        try:
            count = 0
            header = bytearray()
            async with asyncio.timeout(180):
                with part.open('xb') as output:
                    async for chunk in request.stream():
                        count += len(chunk)
                        if count > size or count > LIMIT:
                            raise HTTPException(413, 'Превышен лимит размера.')
                        if len(header) < 20:
                            header.extend(chunk[:20 - len(header)])
                        output.write(chunk)
            if count != size or len(header) < 20:
                raise HTTPException(400, 'Файл передан не полностью.')
            magic, version, length, json_length, json_type = struct.unpack('<5I', header)
            if magic != 0x46546C67 or version != 2 or length != size or json_type != 0x4E4F534A or json_length > size - 20:
                raise HTTPException(400, 'Некорректный GLB 2.0.')
            part.replace(final)
            with connect() as db:
                db.execute('UPDATE models SET ready=1 WHERE id=?', (mid,))
            return {'id': mid, 'expiresAt': now + TTL}
        except BaseException:
            part.unlink(missing_ok=True)
            final.unlink(missing_ok=True)
            with connect() as db:
                db.execute('DELETE FROM models WHERE id=?', (mid,))
            raise
