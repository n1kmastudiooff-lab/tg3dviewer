#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
[ -s /etc/tg3d.env ] || { echo 'Missing /etc/tg3d.env'; exit 1; }
[ -f /etc/letsencrypt/live/n1kma3d.online/fullchain.pem ] || { echo 'HTTPS certificate missing'; exit 1; }
id tg3d >/dev/null 2>&1 || useradd --system --user-group --home-dir /opt/tg3d --shell /usr/sbin/nologin tg3d
mkdir -p /opt/tg3d/app /var/lib/tg3d/models /var/www/tg3d
chown -R tg3d:tg3d /var/lib/tg3d
python3 -m venv /opt/tg3d/venv
/opt/tg3d/venv/bin/pip install -r requirements.txt
install -m 644 app/main.py /opt/tg3d/app/main.py
install -m 644 web/* /var/www/tg3d/
chmod 600 /etc/tg3d.env
install -m 644 tg3d.service /etc/systemd/system/tg3d.service
systemctl daemon-reload
systemctl enable tg3d
systemctl restart tg3d
sleep 2
curl --fail --silent http://127.0.0.1:8000/api/health
backup="/etc/nginx/tg3d-default-backup-$(date +%Y%m%d-%H%M%S)"
cp -a /etc/nginx/sites-available/default "$backup"
install -m 644 nginx.conf /etc/nginx/sites-available/default
if ! nginx -t; then
    cp -a "$backup" /etc/nginx/sites-available/default
    echo 'Nginx configuration restored'; exit 1
fi
systemctl reload nginx
echo 'Installed: https://n1kma3d.online'
