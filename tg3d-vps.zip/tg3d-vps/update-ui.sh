#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
[ -s /var/www/tg3d/index.html ] || { echo 'Existing viewer not found. Use install.sh for first installation.'; exit 1; }
backup="/root/tg3d-ui-backup-$(date +%Y%m%d-%H%M%S).tar.gz"
tar -czf "$backup" -C /var/www tg3d
# Install dependencies first; replace index last. No service/env/model changes.
cp -a web/assets /var/www/tg3d/
for file in app.js style.css step-worker.js measure-worker.js; do
    install -m 644 "web/$file" "/var/www/tg3d/$file"
done
find /var/www/tg3d/assets -type d -exec chmod 755 {} +
find /var/www/tg3d/assets -type f -exec chmod 644 {} +
install -m 644 web/index.html /var/www/tg3d/index.html
printf 'Updated UI 1.0.4. Backup: %s\n' "$backup"
echo 'Close Telegram Mini App completely and open it again.'
