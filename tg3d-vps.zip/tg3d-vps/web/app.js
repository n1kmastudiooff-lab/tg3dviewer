import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {STLLoader} from 'three/addons/loaders/STLLoader.js';
import {OBJLoader} from 'three/addons/loaders/OBJLoader.js';
import {FBXLoader} from 'three/addons/loaders/FBXLoader.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';

const $=id=>document.getElementById(id), MAX=41943040, BOT='tg3d_viewer_bot';
const tg=window.Telegram?.WebApp;
const stage=$('stage'),fileInput=$('file'),uploadButton=$('upload-share');
let model=null, sourceName='', local=false, busy=false, shareUrl='', unitFactor=1, volumeResult=null, measureWorker=null, measureGeneration=0;
const scene=new THREE.Scene();scene.background=new THREE.Color('#d9e7e8');
const perspective=new THREE.PerspectiveCamera(42,1,.001,1000);
const orthographic=new THREE.OrthographicCamera(-1,1,1,-1,.001,1000);
let camera=perspective, orthoHeight=2;
camera.position.set(3,2.2,4);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.75));renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.95;stage.prepend(renderer.domElement);
const materials={gray:new THREE.MeshStandardMaterial({color:'#96999b',roughness:.78,metalness:0,side:THREE.DoubleSide}),teal:new THREE.MeshPhysicalMaterial({color:'#528a9a',roughness:.23,metalness:.18,clearcoat:.65,clearcoatRoughness:.18,side:THREE.DoubleSide})};
scene.add(new THREE.HemisphereLight(0xffffff,0xb8b8b8,.45));
const pmrem=new THREE.PMREMGenerator(renderer),room=new RoomEnvironment(),environment=pmrem.fromScene(room,.04);
scene.environment=environment.texture;scene.environmentIntensity=.35;room.dispose();pmrem.dispose();
for(const [x,y,z] of [[0,1,0],[0,-1,0],[-1,0,0],[1,0,0],[0,0,1],[0,0,-1]]){const light=new THREE.DirectionalLight(0xffffff,y===1?.3:.18);light.position.set(x,y,z);scene.add(light);}
const key=new THREE.DirectionalLight(0xffffff,1.6),fill=new THREE.DirectionalLight(0xffffff,.35);scene.add(key,fill);
const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=false;
let frame=0;
function render(){if(frame)return;frame=requestAnimationFrame(()=>{frame=0;controls.update();renderer.render(scene,camera);});}
controls.addEventListener('change',render);
function resize(){const w=Math.max(stage.clientWidth,1),h=Math.max(stage.clientHeight,1),a=w/h;renderer.setSize(w,h,false);perspective.aspect=a;perspective.updateProjectionMatrix();orthographic.left=-orthoHeight*a/2;orthographic.right=orthoHeight*a/2;orthographic.top=orthoHeight/2;orthographic.bottom=-orthoHeight/2;orthographic.updateProjectionMatrix();render();}
new ResizeObserver(resize).observe(stage);
function lightAngle(){const d=+$('light-angle').value,r=d*Math.PI/180;key.position.set(Math.sin(r)*5,6,Math.cos(r)*5);fill.position.set(-Math.sin(r)*5,2.5,-Math.cos(r)*5);$('angle-label').textContent=d+'°';render();}
function error(message){$('error').textContent=message;$('error').hidden=false;}
function setBusy(value,message='Открываю модель…'){busy=value;$('busy').textContent=message;$('busy').hidden=!value;fileInput.disabled=value;$('open-file').disabled=value;$('units').disabled=value||!model;$('material').disabled=value;uploadButton.disabled=value||!local||!model||!!shareUrl;}
function dispose(obj,original=false){const geometries=new Set(),mats=new Set(),textures=new Set();obj.traverse(n=>{if(n.geometry)geometries.add(n.geometry);if(original&&n.material)for(const m of(Array.isArray(n.material)?n.material:[n.material])){mats.add(m);for(const v of Object.values(m))if(v?.isTexture)textures.add(v);}});for(const g of geometries)g.dispose();for(const t of textures)t.dispose();for(const m of mats)m.dispose();}
function frameModel(){if(!model)return;const box=new THREE.Box3().setFromObject(model),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3());const radius=Math.max(size.length()/2,1e-6),a=Math.max(stage.clientWidth,1)/Math.max(stage.clientHeight,1);const vf=THREE.MathUtils.degToRad(perspective.fov),hf=2*Math.atan(Math.tan(vf/2)*a),distance=radius/Math.sin(Math.min(vf,hf)/2)*1.15;
 for(const c of[perspective,orthographic]){c.near=Math.max(radius/10000,1e-7);c.far=Math.max(radius*100,1);c.zoom=1;c.position.copy(center).add(new THREE.Vector3(.9,.62,1.05).normalize().multiplyScalar(distance));c.lookAt(center);c.updateProjectionMatrix();}
 orthoHeight=radius*2.3/Math.min(a,1);controls.target.copy(center);controls.minDistance=radius*.02;controls.maxDistance=radius*100;controls.minZoom=.01;controls.maxZoom=100;controls.update();resize();}
function projection(){const next=$('projection').value==='orthographic'?orthographic:perspective;if(next===camera)return;const distance=camera.position.distanceTo(controls.target);next.position.copy(camera.position);next.quaternion.copy(camera.quaternion);
 if(next===orthographic){orthoHeight=2*distance*Math.tan(THREE.MathUtils.degToRad(perspective.fov)/2)/perspective.zoom;orthographic.zoom=1;}
 else{const height=orthoHeight/orthographic.zoom;const d=height/(2*Math.tan(THREE.MathUtils.degToRad(perspective.fov)/2));next.position.copy(controls.target).add(camera.position.clone().sub(controls.target).normalize().multiplyScalar(d));next.zoom=1;}
 camera=next;controls.object=camera;controls.update();resize();}
function setMaterial(){if(model)model.traverse(n=>{if(n.isMesh)n.material=materials[$('material').value];});render();}
function stopMeasures(){measureGeneration++;if(measureWorker){measureWorker.terminate();measureWorker=null;}}
const format=n=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:3}).format(n);
const formatVolume=n=>new Intl.NumberFormat('ru-RU',{maximumSignificantDigits:7}).format(n);
function updateDims(){if(!model)return;const s=new THREE.Box3().setFromObject(model).getSize(new THREE.Vector3()).multiplyScalar(1000);for(const axis of['x','y','z'])$('dim-'+axis).textContent=format(s[axis])+' мм';}
function measure(){stopMeasures();volumeResult=null;updateDims();if(!model||!$('show-measures').checked)return;
 let triangles=0;model.traverse(n=>{if(n.isMesh)triangles+=(n.geometry.index?.count||n.geometry.attributes.position.count)/3;});
 if(triangles>500000){$('volume').textContent='—';$('volume-note').textContent='Для объёма поддерживается до 500 000 треугольников. Габариты показаны для всей модели.';return;}
 $('volume').textContent='Считаю…';$('volume-note').textContent='Проверяю замкнутость сетки…';
 model.updateMatrixWorld(true);const meshes=[],transfers=[],v=new THREE.Vector3();
 model.traverse(n=>{if(!n.isMesh)return;const attr=n.geometry.attributes.position,p=new Float64Array(attr.count*3);for(let i=0;i<attr.count;i++){v.fromBufferAttribute(attr,i).applyMatrix4(n.matrixWorld).multiplyScalar(1000);p.set([v.x,v.y,v.z],i*3);}const idx=n.geometry.index?new Uint32Array(n.geometry.index.array):null;meshes.push({positions:p,indices:idx});transfers.push(p.buffer);if(idx)transfers.push(idx.buffer);});
 const generation=measureGeneration;measureWorker=new Worker('./measure-worker.js?v=2');const worker=measureWorker;
 const timeout=setTimeout(()=>{if(generation!==measureGeneration)return;stopMeasures();$('volume').textContent='—';$('volume-note').textContent='Расчёт занял слишком много времени.';},60000);
 worker.onmessage=({data})=>{clearTimeout(timeout);worker.terminate();if(generation!==measureGeneration)return;measureWorker=null;volumeResult=data.volume;$('volume').textContent=data.volume===null?'Не определён':formatVolume(data.volume)+' мм³';$('volume-note').textContent=data.reason||'Оценка по треугольной сетке. Пересечения деталей не вычитаются; самопересечения не проверяются. STEP измеряется после триангуляции.';};
 worker.onerror=()=>{clearTimeout(timeout);worker.terminate();if(generation!==measureGeneration)return;measureWorker=null;$('volume').textContent='—';$('volume-note').textContent='Ошибка расчёта объёма.';};worker.postMessage({meshes},transfers);
}

// Freeze the displayed pose, bake world transforms, discard textures/materials.
function staticGeometry(source){source.updateMatrixWorld(true);const group=new THREE.Group();let vertices=0;source.traverse(n=>{if(!n.isMesh||!n.visible)return;const src=n.geometry,pos=src.attributes.position;if(!pos)return;if(n.isSkinnedMesh)n.skeleton.update();const transforms=[];if(n.isInstancedMesh){for(let j=0;j<n.count;j++){const t=new THREE.Matrix4();n.getMatrixAt(j,t);transforms.push(n.matrixWorld.clone().multiply(t));}}else transforms.push(n.matrixWorld);for(const transform of transforms){const out=new THREE.BufferGeometry(),p=new Float32Array(pos.count*3),v=new THREE.Vector3();for(let i=0;i<pos.count;i++){n.getVertexPosition(i,v);v.applyMatrix4(transform);if(!Number.isFinite(v.x+v.y+v.z))throw new Error('Некорректные координаты геометрии');p.set([v.x,v.y,v.z],i*3);}out.setAttribute('position',new THREE.BufferAttribute(p,3));if(src.index)out.setIndex(src.index.clone());
 // Mirrored instances must retain consistent winding.
 if(transform.determinant()<0){if(out.index){const a=out.index.array;for(let i=0;i<a.length;i+=3)[a[i+1],a[i+2]]=[a[i+2],a[i+1]];}else{for(let i=0;i<p.length;i+=9)for(let j=0;j<3;j++)[p[i+3+j],p[i+6+j]]=[p[i+6+j],p[i+3+j]];}}
 if(src.attributes.normal&&!n.isSkinnedMesh&&!n.morphTargetInfluences?.some(x=>x!==0)){out.setAttribute('normal',src.attributes.normal.clone());out.attributes.normal.applyNormalMatrix(new THREE.Matrix3().getNormalMatrix(transform));}else out.computeVertexNormals();
 out.computeBoundingBox();const mesh=new THREE.Mesh(out,materials[$('material').value]);mesh.name=n.name||'Mesh';group.add(mesh);vertices+=pos.count;}});if(!vertices)throw new Error('В файле нет треугольной геометрии.');return group;}
function stepImport(buffer){return new Promise((resolve,reject)=>{const worker=new Worker('./step-worker.js?v=2');const timer=setTimeout(()=>{worker.terminate();reject(new Error('STEP слишком сложный: превышено время импорта (120 с).'));},120000);function finish(){clearTimeout(timer);worker.terminate();}worker.onerror=()=>{finish();reject(new Error('Не удалось загрузить модуль STEP. Проверь интернет.'));};worker.onmessage=({data})=>{finish();if(data.error){reject(new Error(data.error));return;}const root=new THREE.Group();for(const m of data.meshes){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(m.positions,3));g.setIndex(new THREE.BufferAttribute(m.indices,1));if(m.normals)g.setAttribute('normal',new THREE.BufferAttribute(m.normals,3));else g.computeVertexNormals();const mesh=new THREE.Mesh(g,materials.gray);mesh.name=m.name||'STEP';root.add(mesh);}resolve(root);};worker.postMessage(buffer,[buffer]);});}
async function parse(buffer,ext){const manager=new THREE.LoadingManager();
 // Material textures are deliberately replaced with a local transparent image.
 manager.setURLModifier(url=>url.startsWith('blob:')||url.startsWith('data:')?url:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=');
 if(ext==='stl')return new THREE.Mesh(new STLLoader().parse(buffer),new THREE.MeshStandardMaterial());
 if(ext==='obj')return new OBJLoader(manager).parse(new TextDecoder().decode(buffer));
 if(ext==='fbx')return new FBXLoader(manager).parse(buffer,'');
 if(ext==='step'||ext==='stp')return stepImport(buffer);
 if(buffer.byteLength<20)throw new Error('Повреждённый GLB');const view=new DataView(buffer);if(view.getUint32(0,true)!==0x46546c67||view.getUint32(4,true)!==2||view.getUint32(8,true)!==buffer.byteLength)throw new Error('Ожидается GLB 2.0');
 return (await new GLTFLoader(manager).parseAsync(buffer,'')).scene;
}
function unitNote(ext){if(ext==='glb')return 'GLB: по стандарту метры. Для неверно экспортированных файлов можно исправить масштаб.';if(ext==='step'||ext==='stp')return 'STEP приведён к миллиметрам с учётом единиц CAD-файла.';if(ext==='fbx')return 'FBX: по умолчанию приняты сантиметры. Проверь единицы экспорта; при необходимости измени их здесь.';return 'STL/OBJ не задают единицы. По умолчанию приняты миллиметры — проверь масштаб перед отправкой.';}
async function openModel(buffer,name,isLocal){const ext=name.split('.').pop().toLowerCase();let original=null,next=null;try{original=await parse(buffer,ext);next=staticGeometry(original);}finally{if(original){ // Preserve shared preset materials used by STEP.
 original.traverse(n=>{if(n.material===materials.gray||n.material===materials.teal)n.material=null;});dispose(original,true);}}
 if(model){scene.remove(model);dispose(model);}stopMeasures();model=next;sourceName=name;local=isLocal;unitFactor=ext==='glb'?1000:ext==='fbx'?10:1;model.scale.setScalar(unitFactor/1000);scene.add(model);shareUrl='';$('copy-link').hidden=true;$('units').value=String(unitFactor);$('unit-note').textContent=unitNote(ext);$('filename').textContent=name;$('empty').hidden=true;uploadButton.textContent='Загрузить и поделиться';frameModel();measure();}
async function loadLocal(file){if(!file||busy)return;const ext=file.name.split('.').pop().toLowerCase();$('error').hidden=true;if(!['glb','stl','obj','fbx','step','stp'].includes(ext)){error('Выбери GLB, STL, OBJ, FBX или STEP.');return;}if(file.size>MAX){error('Исходный файл больше 40 МиБ.');return;}setBusy(true,ext==='step'||ext==='stp'?'Читаю STEP… Это может занять до двух минут.':'Открываю модель…');await new Promise(r=>setTimeout(r,30));try{await openModel(await file.arrayBuffer(),file.name,true);}catch(e){error('Не удалось открыть модель: '+e.message);}finally{setBusy(false);}}
async function loadShared(id){if(!/^v_[A-Za-z0-9_-]{32}$/.test(id)){error('Ссылка старой версии или некорректная ссылка. Загрузите модель повторно.');return;}setBusy(true,'Загружаю общую модель…');try{const info=await fetch('/api/models/'+id,{cache:'no-store'});if(!info.ok)throw new Error('Модель не найдена или прошло 36 часов.');const metadata=await info.json();if(metadata.size>MAX)throw new Error('Превышен лимит размера.');const response=await fetch('/api/models/'+id+'/file');if(!response.ok)throw new Error('Ошибка скачивания HTTP '+response.status);const buffer=await response.arrayBuffer();if(buffer.byteLength>MAX)throw new Error('Превышен лимит размера.');await openModel(buffer,metadata.name,false);}catch(e){error(e.message);}finally{setBusy(false);}}
async function upload(){if(!model||!local||busy)return;$('error').hidden=true;if(!tg?.initData){error('Для загрузки открой приложение через @tg3d_viewer_bot в Telegram.');return;}setBusy(true,'Подготавливаю GLB…');await new Promise(r=>setTimeout(r,30));try{
 const buffer=await new GLTFExporter().parseAsync(model,{binary:true,onlyVisible:true});if(buffer.byteLength>MAX)throw new Error('После преобразования GLB больше 40 МиБ. Уменьши исходную сетку. Автоматическое упрощение пока не включено.');
 const name=sourceName.replace(/\.[^.]+$/,'')+'.glb';const blob=new Blob([buffer],{type:'model/gltf-binary'});
 const result=await new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST','/api/models');xhr.timeout=200000;xhr.setRequestHeader('Content-Type','model/gltf-binary');xhr.setRequestHeader('X-Telegram-Init-Data',tg.initData);xhr.setRequestHeader('X-File-Name',encodeURIComponent(name));xhr.upload.onprogress=e=>{if(e.lengthComputable)$('busy').textContent='Загрузка '+Math.round(100*e.loaded/e.total)+'%';};xhr.onload=()=>{let data={};try{data=JSON.parse(xhr.responseText);}catch{}if(xhr.status>=200&&xhr.status<300)resolve(data);else reject(new Error(typeof data.detail==='string'?data.detail:'Ошибка HTTP '+xhr.status));};xhr.onerror=()=>reject(new Error('Нет связи с сервером.'));xhr.ontimeout=()=>reject(new Error('Превышено время загрузки.'));xhr.send(blob);});
 shareUrl='https://t.me/'+BOT+'?startapp='+encodeURIComponent(result.id);$('copy-link').hidden=false;uploadButton.textContent='Загружено';$('filename').textContent=sourceName+' · ссылка на 36 часов';
 }catch(e){error(e.message);}finally{setBusy(false);}}
async function copy(){try{await navigator.clipboard.writeText(shareUrl);$('copy-link').textContent='Скопировано';setTimeout(()=>$('copy-link').textContent='Скопировать ссылку',1800);}catch{error('Скопируй ссылку: '+shareUrl);}}
function settings(show){$('settings').hidden=!show;$('settings-button').setAttribute('aria-expanded',String(show));if(show)$('projection').focus();else $('settings-button').focus();}
$('settings-button').onclick=()=>settings($('settings').hidden);$('close-settings').onclick=()=>settings(false);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('settings').hidden)settings(false);});
$('projection').onchange=projection;$('material').onchange=setMaterial;$('show-measures').onchange=()=>{$('measurements').hidden=!$('show-measures').checked;measure();};
$('units').onchange=()=>{if(!model||busy)return;unitFactor=+$('units').value;model.scale.setScalar(unitFactor/1000);frameModel();measure();if(local&&shareUrl){shareUrl='';$('copy-link').hidden=true;uploadButton.textContent='Загрузить с новым масштабом';uploadButton.disabled=false;}};
$('open-file').onclick=()=>fileInput.click();fileInput.onchange=e=>{loadLocal(e.target.files[0]);e.target.value='';};$('reset').onclick=frameModel;$('light-angle').oninput=lightAngle;uploadButton.onclick=upload;$('copy-link').onclick=copy;
stage.addEventListener('dragover',e=>e.preventDefault());stage.addEventListener('drop',e=>{e.preventDefault();loadLocal(e.dataTransfer.files[0]);});
if(tg){tg.ready();tg.expand();tg.setBackgroundColor?.('#25252b');tg.setBottomBarColor?.('#25252b');if(tg.isVersionAtLeast?.('7.7'))tg.disableVerticalSwipes();}
resize();lightAngle();const query=new URLSearchParams(location.search);const id=tg?.initDataUnsafe?.start_param||query.get('tgWebAppStartParam')||query.get('model');if(id)loadShared(id);
