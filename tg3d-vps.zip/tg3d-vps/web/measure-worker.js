// Coordinates are millimetres. Weld coincident vertices to handle STL and UV seams.
// Test two opposite directed uses of every edge before reporting a volume.
self.onmessage=({data:{meshes}})=>{
 try {
  const vertices=new Map(), edges=new Map(), volumes=[];
  let next=0, bad=false, count=0;
  const tolerance=0.00001; // 0.01 micrometre; no geometric repair is performed.
  function vertex(x,y,z){const k=[x,y,z].map(v=>Math.round(v/tolerance)).join(',');if(!vertices.has(k))vertices.set(k,next++);return vertices.get(k);}
  // Treat disconnected closed shells separately. Holes rely on consistent orientation
  // within a mesh; overlapping independent meshes are summed, not boolean-unioned.
  for(const {positions:p,indices:idx} of meshes){
   let volume=0; edges.clear(); vertices.clear(); next=0;
   const n=idx?idx.length:p.length/3;
   const ox=p[0],oy=p[1],oz=p[2];
   for(let i=0;i<n;i+=3){
    const a=(idx?idx[i]:i)*3,b=(idx?idx[i+1]:i+1)*3,c=(idx?idx[i+2]:i+2)*3;
    const ids=[vertex(p[a],p[a+1],p[a+2]),vertex(p[b],p[b+1],p[b+2]),vertex(p[c],p[c+1],p[c+2])];
    if(new Set(ids).size<3){bad=true;continue;}
    for(let j=0;j<3;j++){const x=ids[j],y=ids[(j+1)%3],key=x<y?x+','+y:y+','+x;const e=edges.get(key)||[0,0];e[0]++;e[1]+=x<y?1:-1;edges.set(key,e);}
    const ax=p[a]-ox,ay=p[a+1]-oy,az=p[a+2]-oz,bx=p[b]-ox,by=p[b+1]-oy,bz=p[b+2]-oz,cx=p[c]-ox,cy=p[c+1]-oy,cz=p[c+2]-oz;
    volume+=(ax*(by*cz-bz*cy)+ay*(bz*cx-bx*cz)+az*(bx*cy-by*cx))/6;
    count++;
   }
   for(const [uses,direction] of edges.values())if(uses!==2||direction!==0){bad=true;break;}
   volumes.push(Math.abs(volume));
  }
  const volume=volumes.reduce((a,b)=>a+b,0);
  self.postMessage({volume:Number.isFinite(volume)&&!bad?volume:null,triangles:count,reason:bad?'Сетка незамкнута, содержит вырожденные грани или несогласованные нормали. Объём недостоверен.':''});
 }catch(e){self.postMessage({volume:null,reason:'Не удалось рассчитать объём: '+e.message});}
};
