self.onmessage = async ({data}) => {
  try {
    const base = 'https://cdn.jsdelivr.net/npm/occt-import-js@0.0.23/dist/';
    importScripts(base + 'occt-import-js.js');
    const occt = await occtimportjs({locateFile: name => base + name});
    const result = occt.ReadStepFile(new Uint8Array(data), {
      linearUnit:'millimeter', linearDeflectionType:'bounding_box_ratio',
      linearDeflection:0.0005, angularDeflection:0.3
    });
    if (!result.success || !result.meshes?.length) throw new Error('STEP не содержит доступных поверхностей или повреждён.');
    const meshes = result.meshes.map(m => ({name:m.name, positions:new Float32Array(m.attributes.position.array), normals:m.attributes.normal ? new Float32Array(m.attributes.normal.array):null, indices:new Uint32Array(m.index.array)}));
    const transfers=meshes.flatMap(m=>[m.positions.buffer,m.indices.buffer,...(m.normals?[m.normals.buffer]:[])]);
    self.postMessage({meshes},transfers);
  } catch(e) { self.postMessage({error:e.message || 'Ошибка STEP'}); }
};
