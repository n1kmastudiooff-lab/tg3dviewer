import html
import re
import zlib
from datetime import datetime, timezone


def render(model, username, ttl):
    mid = model['id']
    if not re.fullmatch(r'v_[A-Za-z0-9_-]{32}', mid):
        raise ValueError('Invalid model ID')
    if not re.fullmatch(r'[A-Za-z0-9_]{5,32}', username):
        raise ValueError('Invalid bot username')
    name = ''.join(c for c in str(model['name']) if c.isprintable())[:180]
    url = f'https://t.me/{username}?startapp={mid}'
    expires = datetime.fromtimestamp(model['created'] + ttl, timezone.utc).strftime('%d.%m.%Y · %H:%M UTC')
    size = f"{model['size'] / 1048576:.2f} МиБ"
    ext = name.rsplit('.', 1)[-1].upper()[:8] if '.' in name else '3D'
    markup = '''<!doctype html><html lang="ru"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}html,body{margin:0;padding:0;background:#343434;color:#e5e5ea;font-family:system-ui,sans-serif}
.card{padding:12px;padding-bottom:calc(12px + env(safe-area-inset-bottom,0px));background:#343434}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px}.brand{font-size:14px;font-weight:500;letter-spacing:-.5px}.tag{color:#ffcc00;font-size:10px;letter-spacing:1px}
 .model{display:flex;align-items:center;gap:10px;margin:12px 0 10px}.details{flex:1;min-width:0}
.icon{width:42px;height:42px;flex-shrink:0;border-radius:14px;background:#ffffff14;display:flex;align-items:center;justify-content:center;border:1px solid #ffffff22}
h1{font-size:15px;line-height:19px;letter-spacing:-.3px;margin:0 0 6px;overflow-wrap:anywhere;font-weight:500;max-height:38px;overflow:hidden}
.meta{display:flex;gap:6px;flex-wrap:wrap}.chip{font-size:10px;line-height:13px;border-radius:12px;background:#1e1e1e;padding:3px 8px;color:#d5d5d9}
.expiry{color:#aaa;font-size:10px;line-height:15px;margin:0 0 10px;overflow-wrap:anywhere}.expiry span{color:#e5e5ea}
a{display:block;text-align:center;text-decoration:none;border-radius:22px;min-height:44px;padding:12px 8px;color:#e5e5ea;background:linear-gradient(150deg,#ffffff30,#ffffff10);border:1px solid #ffffff40;font-size:13px;line-height:18px;font-weight:500;transition:transform .25s cubic-bezier(.22,1,.36,1)}
a:active{transform:scale(.97)}.arrow{color:#ffcc00;margin-left:6px}.foot{font-size:9px;line-height:12px;color:#909095;margin:6px 0 0;text-align:center}
@media(prefers-reduced-motion:reduce){a{transition:none}}
</style></head><body><div class="card"><div class="top"><span class="brand">3D-Viewer</span><span class="tag">MODEL</span></div>
<div class="model"><div class="icon"><svg width="26" height="26" viewBox="0 0 48 48" fill="none"><path d="M24 3L43 14V35L24 46L5 35V14L24 3ZM5 14L24 25L43 14M24 25V46" stroke="#e5e5ea" stroke-width="2.5" stroke-linejoin="round"/><path d="M24 3L43 14" stroke="#ffcc00" stroke-width="2.5" stroke-linecap="round"/></svg></div>
<div class="details"><h1>NAME</h1><div class="meta"><span class="chip">FORMAT</span><span class="chip">SIZE</span></div></div></div>
<p class="expiry">До <span>EXPIRY</span></p><a href="URL">Открыть модель <span class="arrow">↗</span></a><p class="foot">Откроется в мини-приложении</p></div></body></html>'''
    # One-pass substitution: user filenames must never be interpreted as placeholders.
    values = {'NAME': name, 'FORMAT': ext, 'SIZE': size, 'EXPIRY': expires, 'URL': url}
    markup = re.sub(r'NAME|FORMAT|SIZE|EXPIRY|URL', lambda m: html.escape(values[m[0]], quote=True), markup)
    if len(markup.encode()) > 32768 or len(zlib.compress(markup.encode(), 9)) > 4096:
        raise ValueError('Widget too large')
    caption = f'{name}\n{size} · до {expires}'
    keyboard = {'inline_keyboard': [[{'text': 'Открыть модель', 'url': url}]]}
    return {'chat_id': model['owner'], 'html': markup, 'caption': caption, 'reply_markup': keyboard}
