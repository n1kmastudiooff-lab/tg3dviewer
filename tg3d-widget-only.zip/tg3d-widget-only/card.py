import html
import re
import zlib
from datetime import datetime, timezone


def render(model, username, ttl):
    mid = model['id']
    if not re.fullmatch(r'v_[A-Za-z0-9_-]{32}', mid):
        raise ValueError('Invalid model ID')
    if not re.fullmatch(r'[A-Za-z0-9_]{5,32}', username):
        raise ValueError('Invalid bot username')
    name = ''.join(c for c in str(model['name']) if c.isprintable())[:180]
    url = f'https://t.me/{username}?startapp={mid}'
    expires = datetime.fromtimestamp(model['created'] + ttl, timezone.utc).strftime('%d.%m.%Y · %H:%M UTC')
    size = f"{model['size'] / 1048576:.2f} МиБ"
    ext = name.rsplit('.', 1)[-1].upper()[:8] if '.' in name else '3D'
    markup = '''<!doctype html><html lang="ru"><head><meta charset="utf-8"><style>
*{box-sizing:border-box}body{margin:0;padding:8px;background:#000;color:#e5e5ea;font-family:system-ui,sans-serif}
.card{border:1px solid #555;border-radius:30px;padding:20px;background:linear-gradient(145deg,#414141,#171717);box-shadow:inset 0 1px 0 #ffffff30}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px}.brand{font-size:17px;font-weight:500;letter-spacing:-.5px}.tag{color:#ffcc00;font-size:10px;letter-spacing:1px}
.icon{width:64px;height:64px;border-radius:22px;background:#ffffff14;display:flex;align-items:center;justify-content:center;margin:22px 0 16px;border:1px solid #ffffff22}
h1{font-size:20px;line-height:1.25;letter-spacing:-.5px;margin:0 0 14px;overflow-wrap:anywhere;font-weight:500;max-height:75px;overflow:hidden}
.meta{display:flex;gap:8px;flex-wrap:wrap}.chip{font-size:11px;border-radius:20px;background:#1e1e1e;padding:7px 12px;color:#d5d5d9}
.expiry{color:#aaa;font-size:11px;line-height:1.5;margin:16px 0 20px}.expiry span{color:#e5e5ea}
a{display:block;text-align:center;text-decoration:none;border-radius:28px;padding:14px 8px;color:#e5e5ea;background:linear-gradient(150deg,#ffffff30,#ffffff10);border:1px solid #ffffff40;font-size:15px;font-weight:500;transition:transform .25s cubic-bezier(.22,1,.36,1)}
a:active{transform:scale(.97)}.arrow{color:#ffcc00;margin-left:8px}.foot{font-size:10px;line-height:1.4;color:#909095;margin:12px 0 0;text-align:center}
@media(prefers-reduced-motion:reduce){a{transition:none}}
</style></head><body><div class="card"><div class="top"><span class="brand">3D-Viewer</span><span class="tag">MODEL</span></div>
<div class="icon"><svg width="38" height="38" viewBox="0 0 48 48" fill="none"><path d="M24 3L43 14V35L24 46L5 35V14L24 3ZM5 14L24 25L43 14M24 25V46" stroke="#e5e5ea" stroke-width="2.5" stroke-linejoin="round"/><path d="M24 3L43 14" stroke="#ffcc00" stroke-width="2.5" stroke-linecap="round"/></svg></div>
<h1>NAME</h1><div class="meta"><span class="chip">FORMAT</span><span class="chip">SIZE</span></div>
<p class="expiry">Доступна до<br><span>EXPIRY</span></p><a href="URL">Открыть модель <span class="arrow">↗</span></a><p class="foot">Откроется в мини-приложении</p></div></body></html>'''
    # One-pass substitution: user filenames must never be interpreted as placeholders.
    values = {'NAME': name, 'FORMAT': ext, 'SIZE': size, 'EXPIRY': expires, 'URL': url}
    markup = re.sub(r'NAME|FORMAT|SIZE|EXPIRY|URL', lambda m: html.escape(values[m[0]], quote=True), markup)
    if len(markup.encode()) > 32768 or len(zlib.compress(markup.encode(), 9)) > 4096:
        raise ValueError('Widget too large')
    caption = f'{name}\n{size} · до {expires}'
    keyboard = {'inline_keyboard': [[{'text': 'Открыть модель', 'url': url}]]}
    return {'chat_id': model['owner'], 'html': markup, 'caption': caption, 'reply_markup': keyboard}
