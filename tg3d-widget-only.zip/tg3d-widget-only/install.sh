#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" != 0 ]; then echo 'Запусти от root.'; exit 1; fi
cd -- "$(dirname -- "$0")"
test -f /opt/tg3d/app/main.py || { echo 'Не найден /opt/tg3d/app/main.py'; exit 1; }
test -f /etc/tg3d.env || { echo 'Не найден /etc/tg3d.env'; exit 1; }
id tg3d >/dev/null
systemctl is-active --quiet tg3d || { echo 'Сначала должна работать служба tg3d.'; exit 1; }
if [ -e /opt/tg3d-widgets ] || [ -e /etc/systemd/system/tg3d-widgets.service ]; then
  echo 'Дополнение уже установлено. Для включения: systemctl enable --now tg3d-widgets'; exit 1
fi
/usr/bin/python3 - <<'PY'
from pathlib import Path
for name in ('worker.py', 'card.py'):
    compile(Path(name).read_text(), name, 'exec')
PY
install -d -m 755 /opt/tg3d-widgets
install -m 644 worker.py card.py /opt/tg3d-widgets/
install -m 644 tg3d-widgets.service /etc/systemd/system/tg3d-widgets.service
systemctl daemon-reload
if systemctl enable --now tg3d-widgets; then
  echo 'Готово. Нажми Start в личном чате бота, затем загрузи модель через мини-приложение.'
  echo 'Карточка появится в чате примерно через 5–15 секунд.'
else
  systemctl disable --now tg3d-widgets || true
  echo 'Дополнение остановлено. Основной просмотрщик не изменён.'
  journalctl -u tg3d-widgets -n 12 --no-pager
  exit 1
fi
