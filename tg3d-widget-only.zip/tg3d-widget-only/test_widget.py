import tempfile
from pathlib import Path
import sqlite3
import time
import unittest
from unittest.mock import patch
import zlib
import card
import worker


class WidgetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        base = Path(self.temp.name)
        worker.ROOT = base / 'models'
        worker.ROOT.mkdir()
        worker.SOURCE = base / 'models.sqlite3'
        worker.STATE = base / 'state'
        with sqlite3.connect(worker.SOURCE) as db:
            db.execute('CREATE TABLE models (id TEXT PRIMARY KEY,name TEXT,owner INTEGER,size INTEGER,created REAL,ready INTEGER)')
        self.db = worker.open_state()
        self.model = dict(id='v_' + 'a'*32, name='деталь.glb', owner=123, size=450000,
                          created=time.time(), ready=1)

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def row(self, letter, age=0, ready=1):
        row = dict(self.model, id='v_' + letter*32, created=time.time()-age, ready=ready)
        with sqlite3.connect(worker.SOURCE) as db:
            db.execute('INSERT INTO models VALUES (:id,:name,:owner,:size,:created,:ready)', row)
        (worker.ROOT / (row['id'] + '.glb')).write_bytes(b'not read by observer')
        return row

    def status(self):
        return self.db.execute('SELECT status FROM delivery WHERE id=?', (self.model['id'],)).fetchone()[0]

    def test_html_safe_and_within_limits(self):
        self.model['name'] = '<script>alert("NAME URL")</script>' + 'Ж'*180
        payload = card.render(self.model, 'tg3d_viewer_bot', 129600)
        html = payload['html']
        self.assertNotIn('<script>', html)
        self.assertIn('&lt;script&gt;', html)
        self.assertIn('NAME URL', html)
        self.assertLess(len(html.encode()), 32769)
        self.assertLess(len(zlib.compress(html.encode(), 9)), 4097)
        self.assertNotIn('api.telegram.org', html)

    def test_only_new_ready_and_no_source_mutations(self):
        self.row('a')
        self.row('b', age=30)
        self.row('c', ready=0)
        before = worker.SOURCE.read_bytes()
        with patch.object(worker, 'api', return_value={'ok': True}) as api, patch.object(worker.time, 'sleep'):
            worker.scan(self.db, 'tg3d_viewer_bot')
            worker.scan(self.db, 'tg3d_viewer_bot')
            self.assertEqual(api.call_count, 1)
        self.assertEqual(before, worker.SOURCE.read_bytes())
        with worker.source_db() as source:
            with self.assertRaises(sqlite3.OperationalError):
                source.execute('DELETE FROM models')

    def test_rejected_widget_falls_back(self):
        with patch.object(worker, 'api', side_effect=[{'ok': False, 'error_code': 400}, {'ok': True}]) as api:
            worker.deliver(self.db, self.model, 'tg3d_viewer_bot')
            self.assertEqual(api.call_args_list[1].args[0], 'sendMessage')
            self.assertEqual(self.status(), 'sent')

    def test_unknown_delivery_never_retried(self):
        with patch.object(worker, 'api', return_value={'ok': False, 'unknown_delivery': True}) as api:
            worker.deliver(self.db, self.model, 'tg3d_viewer_bot')
            worker.deliver(self.db, self.model, 'tg3d_viewer_bot')
            self.assertEqual(api.call_count, 1)
            self.assertEqual(self.status(), 'unknown')

    def test_403_waits_and_429_persists_pause(self):
        with patch.object(worker, 'api', return_value={'ok': False, 'error_code': 403}) as api:
            worker.deliver(self.db, self.model, 'tg3d_viewer_bot')
            worker.deliver(self.db, self.model, 'tg3d_viewer_bot')
            self.assertEqual(api.call_count, 1)
        self.db.execute('DELETE FROM delivery')
        self.db.commit()
        with patch.object(worker, 'api', return_value={'ok': False, 'error_code': 429, 'parameters': {'retry_after': 60}}):
            worker.deliver(self.db, self.model, 'tg3d_viewer_bot')
        self.assertEqual(self.status(), 'retry')
        self.db.close()
        self.db = worker.open_state()
        with patch.object(worker, 'api') as api:
            worker.scan(self.db, 'tg3d_viewer_bot')
            api.assert_not_called()

    def test_restart_preserves_delivery_and_marks_inflight_unknown(self):
        worker.record(self.db, self.model['id'], 'sending', 1)
        worker.record(self.db, 'v_' + 'd'*32, 'sent', 1)
        self.db.close()
        self.db = worker.open_state()
        self.assertEqual(self.status(), 'unknown')
        self.assertEqual(self.db.execute("SELECT status FROM delivery WHERE id=?", ('v_'+'d'*32,)).fetchone()[0], 'sent')


if __name__ == '__main__':
    unittest.main()
