#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" != 0 ]; then echo 'Запусти от root.'; exit 1; fi
cd -- "$(dirname -- "$0")"
target=/opt/tg3d-widgets
backup="$target/before-narrow-v4"
test -f "$target/worker.py" || { echo 'Дополнение ещё не установлено. Используй install.sh.'; exit 1; }
test -f "$target/card.py"
if [ "${1:-}" = rollback ]; then
  test -f "$backup/worker.py"
  test -f "$backup/card.py"
  systemctl stop tg3d-widgets
  install -m 644 "$backup/worker.py" "$backup/card.py" "$target/"
  systemctl start tg3d-widgets
  echo 'Возвращён дизайн до обновления v4. Старые сообщения не меняются.'
  exit 0
fi
/usr/bin/python3 - <<'PY'
from pathlib import Path
for name in ('worker.py', 'card.py'):
    compile(Path(name).read_text(), name, 'exec')
PY
if [ ! -d "$backup" ]; then
  mkdir -m 700 "$backup"
  cp -p "$target/worker.py" "$target/card.py" "$backup/"
fi
test -f "$backup/worker.py"
test -f "$backup/card.py"
restore_on_error() {
  trap - ERR
  echo 'Ошибка обновления. Восстанавливаю предыдущие файлы.'
  install -m 644 "$backup/worker.py" "$backup/card.py" "$target/"
  systemctl restart tg3d-widgets || true
  exit 1
}
trap restore_on_error ERR
systemctl stop tg3d-widgets
install -m 644 worker.py card.py "$target/"
systemctl start tg3d-widgets
trap - ERR
echo 'Готово. Загрузи модель через мини-приложение: новая карточка будет компактной.'
