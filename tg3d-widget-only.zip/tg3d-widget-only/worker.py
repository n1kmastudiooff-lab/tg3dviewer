"""Read-only model observer. No getUpdates, upload handlers or API changes."""
import argparse
import fcntl
import json
import logging
import os
from pathlib import Path
import sqlite3
import socket
import time
import urllib.error
import urllib.request
from card import render

LOG = logging.getLogger('tg3d-widgets')
ROOT = Path(os.environ.get('MODELS_DIR', '/var/lib/tg3d/models'))
SOURCE = ROOT.parent / 'models.sqlite3'
STATE = Path(os.environ.get('WIDGET_STATE_DIR', '/var/lib/tg3d-widgets'))
TOKEN = os.environ.get('BOT_TOKEN', '')
TTL = int(os.environ.get('MODEL_TTL_HOURS', '36')) * 3600


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def api(method, payload):
    request = urllib.request.Request(
        f'https://api.telegram.org/bot{TOKEN}/{method}',
        data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.build_opener(NoRedirect()).open(request, timeout=20) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        try:
            result = json.loads(exc.read(65536))
            if isinstance(result, dict):
                return result
        except (ValueError, OSError):
            pass
        return {'ok': False, 'error_code': exc.code}
    except Exception:
        # Never log exception text: urllib errors can contain a bot token.
        return {'ok': False, 'unknown_delivery': True}


def source_db():
    db = sqlite3.connect(SOURCE.resolve().as_uri() + '?mode=ro', uri=True, timeout=5)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA query_only=ON')
    return db


def check():
    if not TOKEN or ':' not in TOKEN or TTL <= 0:
        raise RuntimeError('Проверь BOT_TOKEN и MODEL_TTL_HOURS в /etc/tg3d.env')
    with source_db() as db:
        db.execute('SELECT id,name,owner,size,created,ready FROM models LIMIT 1').fetchall()
    result = api('getMe', {})
    if not result.get('ok') or not result.get('result', {}).get('username'):
        raise RuntimeError('Не удалось проверить бота через getMe. Проверь токен и соединение.')
    LOG.info('Проверка пройдена: база доступна только для чтения, токен действителен.')
    return result['result']['username']


def open_state():
    STATE.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(STATE / 'delivery.sqlite3')
    db.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY,value REAL)')
    db.execute('CREATE TABLE IF NOT EXISTS delivery (id TEXT PRIMARY KEY,status TEXT,attempts INTEGER,next REAL)')
    db.execute('INSERT OR IGNORE INTO settings VALUES (?,?)', ('since', time.time()))
    # A crash after sending is indistinguishable from a failed send. Avoid duplicates.
    db.execute("UPDATE delivery SET status='unknown' WHERE status='sending'")
    db.commit()
    return db


def record(db, mid, status, attempts, next_at=0):
    db.execute('INSERT OR REPLACE INTO delivery VALUES (?,?,?,?)', (mid, status, attempts, next_at))
    db.commit()


def deliver(db, model, username):
    mid = model['id']
    previous = db.execute('SELECT status,attempts,next FROM delivery WHERE id=?', (mid,)).fetchone()
    if previous and (previous[0] != 'retry' or previous[2] > time.time()):
        return 0
    attempts = (previous[1] if previous else 0) + 1
    if attempts > 12:
        record(db, mid, 'failed', attempts)
        return 0
    try:
        payload = render(model, username, TTL)
        if not isinstance(model['owner'], int) or model['owner'] <= 0:
            raise ValueError('not a private user')
    except (ValueError, TypeError, OverflowError):
        record(db, mid, 'invalid', attempts)
        return 0
    record(db, mid, 'sending', attempts)
    # Caption and keyboard are only used if Telegram rejects the widget.
    # The successful widget message has no text or buttons outside its HTML.
    result = api('sendWidget', {'chat_id': payload['chat_id'], 'html': payload['html']})
    code = result.get('error_code')
    # Explicit rejection only. Timeouts/5xx might mean Telegram already sent the card.
    if code in (400, 404):
        result = api('sendMessage', {'chat_id': model['owner'], 'text': payload['caption'],
                                    'reply_markup': payload['reply_markup']})
        code = result.get('error_code')
    if result.get('ok'):
        record(db, mid, 'sent', attempts)
        LOG.info('Карточка отправлена: %s', mid)
    elif code == 429:
        delay = max(1, int(result.get('parameters', {}).get('retry_after', 60)))
        record(db, mid, 'retry', attempts, time.time() + delay)
        db.execute('INSERT OR REPLACE INTO settings VALUES (?,?)', ('pause', time.time() + delay))
        db.commit()
        return delay
    elif code == 403 or (code == 400 and 'chat not found' in result.get('description', '').lower()):
        record(db, mid, 'retry', attempts, time.time() + 600)
        LOG.warning('Доставка недоступна: пользователь должен нажать Start и разблокировать бота. %s', mid)
    elif result.get('unknown_delivery') or (isinstance(code, int) and code >= 500):
        record(db, mid, 'unknown', attempts)
        LOG.warning('Доставка не подтверждена; повтор отключён во избежание дубля: %s', mid)
    else:
        record(db, mid, 'failed', attempts)
        LOG.warning('Telegram отклонил карточку, код %s: %s', code, mid)
    return 1.1  # conservative pacing for one bot


def scan(db, username):
    since = db.execute("SELECT value FROM settings WHERE key='since'").fetchone()[0]
    pause = db.execute("SELECT value FROM settings WHERE key='pause'").fetchone()
    if pause and pause[0] > time.time():
        return
    after = ''
    while True:
        with source_db() as source:
            rows = source.execute('SELECT * FROM models WHERE ready=1 AND created>=? AND created>? AND id>? ORDER BY id LIMIT 200',
                                  (since, time.time() - TTL, after)).fetchall()
        if not rows:
            return
        for row in rows:
            after = row['id']
            # Mini App uploads are GLB in this project; old server versions use this filename.
            if not (ROOT / (row['id'] + '.glb')).is_file():
                continue
            delay = deliver(db, dict(row), username)
            if delay:
                time.sleep(min(delay, 5))
                pause = db.execute("SELECT value FROM settings WHERE key='pause'").fetchone()
                if pause and pause[0] > time.time():
                    return


def run():
    username = check()
    STATE.mkdir(parents=True, exist_ok=True)
    with (STATE / 'worker.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        with open_state() as db:
            LOG.info('Ожидаю новые загрузки из мини-приложения. Старые модели не рассылаются.')
            address = os.environ.get('NOTIFY_SOCKET')
            if address:
                if address.startswith('@'):
                    address = '\0' + address[1:]
                with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as notification:
                    notification.connect(address)
                    notification.sendall(b'READY=1')
            while True:
                try:
                    scan(db, username)
                except (sqlite3.Error, OSError):
                    LOG.warning('База временно недоступна. Повтор через 5 секунд.')
                time.sleep(5)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(levelname)s %(message)s')
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    try:
        check() if args.check else run()
    except Exception as exc:
        LOG.error('Не удалось запустить дополнение (%s). Проверь базу, настройки и доступ к Telegram.', type(exc).__name__)
        raise SystemExit(1)
