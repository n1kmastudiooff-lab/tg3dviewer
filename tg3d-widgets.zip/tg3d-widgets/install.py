"""Run as root using the existing project's Python environment."""
from pathlib import Path
import datetime
import os
import shutil
import subprocess
import sys

target = Path('/opt/tg3d/app/bot_worker.py')
module = target.with_name('model_widget.py')
backup = target.with_name('bot_worker.before-widgets.py')
old = "await message.answer('Модель загружена. Она будет доступна 36 часов.', reply_markup=open_keyboard(mid))"
new = 'await send_model_card(message, bot, mid, clean_name(name), size, TTL, open_keyboard(mid))'
if os.geteuid() != 0:
    sys.exit('Запусти от root.')
if len(sys.argv) > 1 and sys.argv[1] == 'rollback':
    if not backup.is_file():
        sys.exit('Резервная копия не найдена.')
    shutil.copy2(backup, target)
    subprocess.run(['systemctl', 'restart', 'tg3d-bot'], check=True)
    print('Прежний обработчик восстановлен; сайт и модели не изменялись.')
    sys.exit()
if not target.is_file():
    sys.exit('Не найден установленный bot_worker.py. Сначала установи загрузку через чат.')
source = target.read_text()
if 'from model_widget import send_model_card' in source:
    sys.exit('Дополнение уже установлено.')
if source.count(old) != 1:
    sys.exit('Версия обработчика отличается. Установка остановлена без изменений.')
import aiohttp
updated = 'from model_widget import send_model_card\n' + source.replace(old, new)
compile(updated, str(target), 'exec')
addon = Path(__file__).with_name('model_widget.py')
compile(addon.read_text(), str(addon), 'exec')
if backup.exists():
    sys.exit('Копия предыдущей установки уже существует. Сохрани её под другим именем перед повторной установкой.')
shutil.copy2(target, backup)
if module.exists():
    shutil.copy2(module, module.with_name('model_widget.saved-' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '.py'))
try:
    shutil.copyfile(addon, module)
    module.chmod(0o644)
    temp = target.with_suffix('.widget-new')
    temp.write_text(updated)
    temp.chmod(target.stat().st_mode & 0o777)
    os.replace(temp, target)
    subprocess.run(['systemctl', 'restart', 'tg3d-bot'], check=True)
except BaseException:
    shutil.copy2(backup, target)
    subprocess.run(['systemctl', 'restart', 'tg3d-bot'])
    raise
print('Установлено. Отправь новый файл боту. Для отката:')
print('/opt/tg3d/venv/bin/python ' + str(Path(__file__).resolve()) + ' rollback')
