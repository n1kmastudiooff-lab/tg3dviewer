"""Optional message cards. No model data or database changes."""
import asyncio
import html
import logging
import os
import re
import zlib
from datetime import datetime, timezone

import aiohttp


def card_html(name, size, url, expires):
    title = html.escape(name[:180])
    ext = html.escape(name.rsplit('.', 1)[-1].upper()[:8])
    date = datetime.fromtimestamp(expires, timezone.utc).strftime('%d.%m %H:%M UTC')
    source = f'''<style>body{{padding:16px;font-family:system-ui;color:var(--tg-theme-text-color)}}h3{{margin:0 0 12px;overflow-wrap:anywhere}}p{{color:var(--tg-theme-hint-color)}}a{{display:block;text-align:center;padding:13px;border-radius:18px;background:var(--tg-theme-button-color);color:var(--tg-theme-button-text-color);text-decoration:none}}</style><h3>{title}</h3><p>{ext} · {size / 1048576:.2f} МиБ</p><p>Доступна до {date}</p><a href="{html.escape(url, quote=True)}">Открыть 3D-модель</a>'''
    encoded = source.encode('utf-8')
    if len(encoded) > 32768 or len(zlib.compress(encoded, 9)) > 4096:
        raise ValueError('Widget size limit')
    return source


async def send_model_card(message, bot, mid, name, size, ttl, fallback_keyboard):
    caption = f'{name[:180]}\n{size / 1048576:.2f} МиБ · хранение {ttl // 3600} ч.'
    if os.environ.get('MODEL_WIDGETS_ENABLED', '1') != '0' and message.chat.type == 'private':
        try:
            username = (await bot.get_me()).username
            if not username or not re.fullmatch(r'v_[A-Za-z0-9_-]{32}', mid):
                raise ValueError('Invalid model link')
            url = f'https://t.me/{username}?startapp={mid}'
            markup = {'inline_keyboard': [[{'text': 'Открыть 3D-модель', 'url': url}]]}
            payload = dict(chat_id=message.chat.id, html=card_html(name, size, url, __import__('time').time() + ttl), caption=caption, reply_markup=markup)
            # Raw API avoids requiring an aiogram release that knows sendWidget.
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as session:
                async with session.post(f'https://api.telegram.org/bot{bot.token}/sendWidget', json=payload) as response:
                    result = await response.json()
                    if response.status == 200 and result.get('ok'):
                        return
                    if result.get('error_code') == 429:
                        await asyncio.sleep(min(int(result.get('parameters', {}).get('retry_after', 1)), 30))
            logging.warning('Model widget rejected; using ordinary reply')
        except Exception:
            # Never log exceptions containing the Bot API URL/token.
            logging.warning('Model widget unavailable; using ordinary reply')
    await message.answer(caption, parse_mode=None, reply_markup=fallback_keyboard)
